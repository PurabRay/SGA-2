# Fleet Management System

This project is an Express API for managing vehicles, telemetry, location searches, and SMS alerts. It includes an API gateway, Swagger documentation, and a Mocha/Chai test suite.

## Install and run

```bash
npm install
copy .env.example .env
npm start
```

Swagger is available at `http://localhost:3000/docs` and the map page is at `http://localhost:3000/map-demo/map-demo.html`. Add `?demo=1` to the map URL to load the sample view.

Use `fleet-demo-key` as the API key. Demo users:

- `admin@fleet.test` / `admin123`
- `operator@fleet.test` / `operator123`

```bash
npm test
```

## Architecture

The Express app acts as the gateway. It checks the API key, applies rate limiting, and sends requests to the user, vehicle, telemetry, maps, and notification routes.

The geocoding service supports `Central Depot`, `Mumbai Depot`, and `Bengaluru Depot`. GPS positions are updated when telemetry is received, and nearby vehicles are calculated using distance in kilometres. SMS delivery is mocked and every notification is saved with a `sent` or `failed` status.

## Example requests

```bash
# Login (copy token from response)
curl -X POST http://localhost:3000/api/users/login -H "x-api-key: fleet-demo-key" -H "Content-Type: application/json" -d "{\"email\":\"admin@fleet.test\",\"password\":\"admin123\"}"

# Register, then search nearby
curl -X POST http://localhost:3000/api/vehicles -H "x-api-key: fleet-demo-key" -H "Authorization: Bearer TOKEN" -H "Content-Type: application/json" -d "{\"registrationNumber\":\"DL01AB1234\",\"address\":\"Central Depot\"}"
curl "http://localhost:3000/api/vehicles/nearby?latitude=28.6139&longitude=77.2090&radiusKm=5" -H "x-api-key: fleet-demo-key" -H "Authorization: Bearer TOKEN"
```

For screenshots, show Swagger UI, the nearby vehicles response, a critical status update followed by the notifications list, and a request without an API key returning `401`.
