const request = require('supertest');
const { expect } = require('chai');
const { createApp } = require('../src/app');
const { reset, state } = require('../src/data/store');

const apiKey = { 'x-api-key': 'test-api-key' };
let app, adminToken, operatorToken;
async function login(email, password) {
  const response = await request(app).post('/api/users/login').set(apiKey).send({ email, password });
  return response.body.token;
}
async function register(registrationNumber, address = 'Central Depot') {
  return request(app).post('/api/vehicles').set(apiKey).set('Authorization', `Bearer ${adminToken}`).send({ registrationNumber, address });
}
beforeEach(async () => { reset(); app = createApp(); adminToken = await login('admin@fleet.test', 'admin123'); operatorToken = await login('operator@fleet.test', 'operator123'); });

describe('Fleet Management critical flows', () => {
  it('authenticates a user and verifies their JWT on a protected endpoint', async () => {
    const response = await request(app).get('/api/users/me').set(apiKey).set('Authorization', `Bearer ${adminToken}`);
    expect(response.status).to.equal(200); expect(response.body).to.include({ email: 'admin@fleet.test', role: 'admin' });
  });
  it('registers and retrieves a geocoded vehicle', async () => {
    const created = await register('DL01AB1234');
    expect(created.status).to.equal(201); expect(created.body.latitude).to.equal(28.6139);
    const listed = await request(app).get('/api/vehicles').set(apiKey).set('Authorization', `Bearer ${adminToken}`);
    expect(listed.body).to.have.length(1); expect(listed.body[0].id).to.equal(created.body.id);
  });
  it('stores telemetry and updates the vehicle GPS location', async () => {
    const vehicle = (await register('DL01AB1235')).body;
    const telemetry = await request(app).post('/api/telemetry').set(apiKey).set('Authorization', `Bearer ${adminToken}`).send({ vehicleId: vehicle.id, latitude: 28.62, longitude: 77.21, speedKph: 47 });
    expect(telemetry.status).to.equal(201);
    const vehicleRead = await request(app).get(`/api/vehicles/${vehicle.id}`).set(apiKey).set('Authorization', `Bearer ${adminToken}`);
    expect(vehicleRead.body).to.include({ latitude: 28.62, longitude: 77.21 });
  });
  it('triggers and records a sent SMS for a critical status event', async () => {
    const vehicle = (await register('DL01AB1236')).body;
    const updated = await request(app).patch(`/api/vehicles/${vehicle.id}/status`).set(apiKey).set('Authorization', `Bearer ${adminToken}`).send({ status: 'out_of_service', event: 'engine_fault' });
    expect(updated.status).to.equal(200); expect(updated.body.notification.status).to.equal('sent');
    expect(state.notifications).to.have.length(1); expect(state.notifications[0]).to.include({ event: 'engine_fault', status: 'sent' });
  });
  it('prevents an operator from deleting a vehicle', async () => {
    const vehicle = (await register('DL01AB1237')).body;
    const response = await request(app).delete(`/api/vehicles/${vehicle.id}`).set(apiKey).set('Authorization', `Bearer ${operatorToken}`);
    expect(response.status).to.equal(403);
  });
  it('finds vehicles within a requested radius', async () => {
    await register('DL01AB1238', 'Central Depot'); await register('MH01AB1239', 'Mumbai Depot');
    const response = await request(app).get('/api/vehicles/nearby?latitude=28.6139&longitude=77.2090&radiusKm=5').set(apiKey).set('Authorization', `Bearer ${adminToken}`);
    expect(response.status).to.equal(200); expect(response.body.vehicles).to.have.length(1); expect(response.body.vehicles[0].registrationNumber).to.equal('DL01AB1238');
  });
  it('enforces the Gateway API key before service routing', async () => {
    const response = await request(app).get('/api/vehicles');
    expect(response.status).to.equal(401); expect(response.body.error).to.match(/API key/);
  });
});
