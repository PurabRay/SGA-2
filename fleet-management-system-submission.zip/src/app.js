const express = require('express');
const rateLimit = require('express-rate-limit');
const swaggerUi = require('swagger-ui-express');
const spec = require('./openapi');
const users = require('./routes/users');
const vehicles = require('./routes/vehicles');
const telemetry = require('./routes/telemetry');
const maps = require('./routes/maps');
const notifications = require('./routes/notifications');

function apiKey(req, res, next) {
  if (req.path === '/health') return next();
  const required = process.env.API_KEY || 'fleet-demo-key';
  return req.get('x-api-key') === required ? next() : res.status(401).json({ error: 'Invalid or missing API key' });
}
function createApp() {
  const app = express();
  app.use(express.json());
  app.get('/health', (req, res) => res.json({ status: 'ok', services: ['users', 'vehicles', 'telemetry', 'maps', 'notifications'] }));
  app.use('/docs', swaggerUi.serve, swaggerUi.setup(spec));
  app.use('/map-demo', express.static('public'));
  app.use('/api', rateLimit({ windowMs: 60_000, limit: Number(process.env.RATE_LIMIT_MAX || 60), standardHeaders: 'draft-7', legacyHeaders: false, message: { error: 'Too many requests; try again later' } }), apiKey);
  app.use('/api/users', users);
  app.use('/api/vehicles', vehicles);
  app.use('/api/telemetry', telemetry);
  app.use('/api/maps', maps);
  app.use('/api/notifications', notifications);
  app.use('/api', (req, res) => res.status(404).json({ error: 'Gateway route or backend service endpoint not found' }));
  app.use((err, req, res, next) => { console.error(err); res.status(503).json({ error: 'Requested backend service is unavailable' }); });
  return app;
}
module.exports = { createApp };
