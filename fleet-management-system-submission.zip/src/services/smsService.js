const { randomUUID } = require('crypto');

async function sendSms({ to, body }) {
  if (!to || !body || String(to).includes('fail')) throw new Error('Mock SMS delivery failed');
  return { provider: 'mock-sms', messageId: `sms_${randomUUID()}`, status: 'sent' };
}
module.exports = { sendSms };
