const addressBook = {
  'central depot': { latitude: 28.6139, longitude: 77.2090 },
  'mumbai depot': { latitude: 19.0760, longitude: 72.8777 },
  'bengaluru depot': { latitude: 12.9716, longitude: 77.5946 }
};

function geocode(address) {
  const result = addressBook[String(address || '').trim().toLowerCase()];
  return result ? { ...result } : null;
}

function distanceKm(a, b) {
  const rad = value => value * Math.PI / 180;
  const earthRadiusKm = 6371;
  const dLat = rad(b.latitude - a.latitude);
  const dLon = rad(b.longitude - a.longitude);
  const h = Math.sin(dLat / 2) ** 2 + Math.cos(rad(a.latitude)) * Math.cos(rad(b.latitude)) * Math.sin(dLon / 2) ** 2;
  return 2 * earthRadiusKm * Math.atan2(Math.sqrt(h), Math.sqrt(1 - h));
}
module.exports = { geocode, distanceKm };
