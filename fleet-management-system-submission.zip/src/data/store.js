const state = { users: [], vehicles: [], telemetry: [], notifications: [] };

function reset() {
  state.users = [
    { id: 'u-admin', name: 'Fleet Admin', email: 'admin@fleet.test', password: 'admin123', role: 'admin', phone: '+15550000001' },
    { id: 'u-operator', name: 'Fleet Operator', email: 'operator@fleet.test', password: 'operator123', role: 'operator', phone: '+15550000002' }
  ];
  state.vehicles = [];
  state.telemetry = [];
  state.notifications = [];
}
reset();
module.exports = { state, reset };
