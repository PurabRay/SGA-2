module.exports = {
  openapi: '3.0.3',
  info: { title: 'Fleet Management System API', version: '1.0.0', description: 'All operational endpoints are routed via the API Gateway and require `x-api-key`. JWT is required unless stated otherwise.' },
  servers: [{ url: 'http://localhost:3000' }],
  components: {
    securitySchemes: { ApiKey: { type: 'apiKey', in: 'header', name: 'x-api-key' }, BearerAuth: { type: 'http', scheme: 'bearer', bearerFormat: 'JWT' } },
    schemas: {
      Vehicle: { type: 'object', required: ['registrationNumber'], properties: { id: { type: 'string' }, registrationNumber: { type: 'string', example: 'DL01AB1234' }, status: { type: 'string', example: 'operational' }, latitude: { type: 'number' }, longitude: { type: 'number' } } },
      Telemetry: { type: 'object', required: ['vehicleId', 'latitude', 'longitude'], properties: { vehicleId: { type: 'string' }, latitude: { type: 'number', example: 28.614 }, longitude: { type: 'number', example: 77.209 }, speedKph: { type: 'number', example: 55 } } },
      Error: { type: 'object', properties: { error: { type: 'string' } } }
    }
  },
  paths: {
    '/api/users/login': { post: { summary: 'Log in and receive a JWT', security: [{ ApiKey: [] }], requestBody: { required: true, content: { 'application/json': { example: { email: 'admin@fleet.test', password: 'admin123' } } } }, responses: { 200: { description: 'Authenticated' }, 401: { description: 'Invalid login', content: { 'application/json': { schema: { $ref: '#/components/schemas/Error' } } } } } } },
    '/api/users/me': { get: { summary: 'Get current user', security: [{ ApiKey: [], BearerAuth: [] }], responses: { 200: { description: 'Current user' }, 401: { description: 'Missing or invalid JWT' } } } },
    '/api/vehicles': { post: { summary: 'Register vehicle', security: [{ ApiKey: [], BearerAuth: [] }], requestBody: { required: true, content: { 'application/json': { schema: { $ref: '#/components/schemas/Vehicle' }, example: { registrationNumber: 'DL01AB1234', address: 'Central Depot' } } } }, responses: { 201: { description: 'Created', content: { 'application/json': { schema: { $ref: '#/components/schemas/Vehicle' } } } }, 400: { description: 'Validation error' }, 403: { description: 'Role forbidden' } } }, get: { summary: 'List vehicles', security: [{ ApiKey: [], BearerAuth: [] }], responses: { 200: { description: 'Vehicles' } } } },
    '/api/vehicles/nearby': { get: { summary: 'Find nearby vehicles', security: [{ ApiKey: [], BearerAuth: [] }], parameters: [{ name: 'latitude', in: 'query', required: true, schema: { type: 'number' } }, { name: 'longitude', in: 'query', required: true, schema: { type: 'number' } }, { name: 'radiusKm', in: 'query', required: true, schema: { type: 'number' } }], responses: { 200: { description: 'Vehicles within radius' }, 400: { description: 'Invalid search data' } } } },
    '/api/vehicles/{id}/status': { patch: { summary: 'Update vehicle status and trigger critical-event SMS', security: [{ ApiKey: [], BearerAuth: [] }], parameters: [{ name: 'id', in: 'path', required: true, schema: { type: 'string' } }], requestBody: { content: { 'application/json': { example: { status: 'out_of_service', event: 'engine_fault' } } } }, responses: { 200: { description: 'Updated; response includes notification delivery status' }, 404: { description: 'Vehicle absent' } } } },
    '/api/vehicles/{id}': { delete: { summary: 'Delete vehicle (admin only)', security: [{ ApiKey: [], BearerAuth: [] }], parameters: [{ name: 'id', in: 'path', required: true, schema: { type: 'string' } }], responses: { 204: { description: 'Deleted' }, 403: { description: 'Operator cannot delete' } } } },
    '/api/telemetry': { post: { summary: 'Store telemetry and update GPS location', security: [{ ApiKey: [], BearerAuth: [] }], requestBody: { content: { 'application/json': { schema: { $ref: '#/components/schemas/Telemetry' } } } }, responses: { 201: { description: 'Stored' }, 404: { description: 'Vehicle absent' } } } },
    '/api/maps/geocode': { get: { summary: 'Geocode supported depot address', security: [{ ApiKey: [], BearerAuth: [] }], parameters: [{ name: 'address', in: 'query', required: true, schema: { type: 'string' } }], responses: { 200: { description: 'Coordinates' }, 404: { description: 'Address unavailable' } } } },
    '/api/notifications': { get: { summary: 'List SMS notification audit log (admin only)', security: [{ ApiKey: [], BearerAuth: [] }], responses: { 200: { description: 'Notification records with sent/failed status' } } } }
  }
};
