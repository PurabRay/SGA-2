const jwt = require('jsonwebtoken');
const { state } = require('../data/store');
const secret = () => process.env.JWT_SECRET || 'development-only-secret';

function authenticate(req, res, next) {
  const token = req.headers.authorization?.replace(/^Bearer\s+/i, '');
  if (!token) return res.status(401).json({ error: 'Authentication token is required' });
  try {
    const payload = jwt.verify(token, secret());
    req.user = state.users.find(user => user.id === payload.sub);
    if (!req.user) return res.status(401).json({ error: 'User no longer exists' });
    return next();
  } catch {
    return res.status(401).json({ error: 'Invalid or expired token' });
  }
}
function allow(...roles) {
  return (req, res, next) => roles.includes(req.user.role)
    ? next()
    : res.status(403).json({ error: 'Insufficient role permissions' });
}
module.exports = { authenticate, allow, secret };
