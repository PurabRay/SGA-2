const express = require('express');
const { state } = require('../data/store');
const { authenticate, allow } = require('../middleware/auth');
const router = express.Router();
router.get('/', authenticate, allow('admin'), (req, res) => res.json(state.notifications));
module.exports = router;
