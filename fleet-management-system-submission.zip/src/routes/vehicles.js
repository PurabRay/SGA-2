const express = require('express');
const { randomUUID } = require('crypto');
const { state } = require('../data/store');
const { geocode, distanceKm } = require('../services/geoService');
const { sendSms } = require('../services/smsService');
const { authenticate, allow } = require('../middleware/auth');
const router = express.Router();

const criticalEvents = new Set(['engine_fault', 'low_battery', 'emergency_stop']);
async function createNotification(vehicle, event) {
  const admin = state.users.find(user => user.role === 'admin');
  const notification = { id: randomUUID(), vehicleId: vehicle.id, event, to: admin?.phone, status: 'pending', createdAt: new Date().toISOString() };
  state.notifications.push(notification);
  try { Object.assign(notification, await sendSms({ to: notification.to, body: `Alert: ${vehicle.registrationNumber} reported ${event}.` })); }
  catch (error) { notification.status = 'failed'; notification.error = error.message; }
  return notification;
}

router.post('/', authenticate, allow('admin', 'operator'), (req, res) => {
  const { registrationNumber, address, latitude, longitude, status = 'operational' } = req.body;
  if (!registrationNumber) return res.status(400).json({ error: 'registrationNumber is required' });
  if (state.vehicles.some(v => v.registrationNumber === registrationNumber)) return res.status(409).json({ error: 'Vehicle is already registered' });
  const coordinates = Number.isFinite(latitude) && Number.isFinite(longitude) ? { latitude, longitude } : geocode(address);
  const vehicle = { id: randomUUID(), registrationNumber, address: address || null, status, latitude: coordinates?.latitude ?? null, longitude: coordinates?.longitude ?? null, createdAt: new Date().toISOString() };
  state.vehicles.push(vehicle);
  return res.status(201).json(vehicle);
});
router.get('/', authenticate, (req, res) => res.json(state.vehicles));
router.get('/nearby', authenticate, (req, res) => {
  const latitude = Number(req.query.latitude), longitude = Number(req.query.longitude), radiusKm = Number(req.query.radiusKm);
  if (![latitude, longitude, radiusKm].every(Number.isFinite) || radiusKm <= 0) return res.status(400).json({ error: 'latitude, longitude and positive radiusKm are required' });
  const origin = { latitude, longitude };
  const nearby = state.vehicles.filter(v => Number.isFinite(v.latitude) && Number.isFinite(v.longitude)).map(v => ({ ...v, distanceKm: Number(distanceKm(origin, v).toFixed(2)) })).filter(v => v.distanceKm <= radiusKm);
  return res.json({ origin, radiusKm, vehicles: nearby });
});
router.get('/:id', authenticate, (req, res) => { const v = state.vehicles.find(v => v.id === req.params.id); return v ? res.json(v) : res.status(404).json({ error: 'Vehicle not found' }); });
router.patch('/:id/status', authenticate, allow('admin', 'operator'), async (req, res) => {
  const vehicle = state.vehicles.find(v => v.id === req.params.id); if (!vehicle) return res.status(404).json({ error: 'Vehicle not found' });
  const { status, event } = req.body; if (!status) return res.status(400).json({ error: 'status is required' });
  vehicle.status = status; let notification = null;
  if (criticalEvents.has(event) || status === 'out_of_service') notification = await createNotification(vehicle, event || `status changed to ${status}`);
  return res.json({ vehicle, notification });
});
router.delete('/:id', authenticate, allow('admin'), (req, res) => { const index = state.vehicles.findIndex(v => v.id === req.params.id); if (index < 0) return res.status(404).json({ error: 'Vehicle not found' }); state.vehicles.splice(index, 1); return res.status(204).send(); });
module.exports = router;
