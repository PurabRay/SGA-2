const express = require('express');
const jwt = require('jsonwebtoken');
const { state } = require('../data/store');
const { authenticate, secret } = require('../middleware/auth');
const router = express.Router();

router.post('/login', (req, res) => {
  const { email, password } = req.body;
  const user = state.users.find(item => item.email === email && item.password === password);
  if (!user) return res.status(401).json({ error: 'Invalid email or password' });
  const token = jwt.sign({ sub: user.id, role: user.role }, secret(), { expiresIn: '1h' });
  return res.json({ token, user: { id: user.id, name: user.name, email: user.email, role: user.role } });
});
router.get('/me', authenticate, (req, res) => res.json({ id: req.user.id, name: req.user.name, email: req.user.email, role: req.user.role }));
module.exports = router;
