const express = require('express');
const { geocode } = require('../services/geoService');
const { authenticate } = require('../middleware/auth');
const router = express.Router();
router.get('/geocode', authenticate, (req, res) => { const result = geocode(req.query.address); return result ? res.json({ address: req.query.address, ...result, provider: 'OpenStreetMap mock adapter' }) : res.status(404).json({ error: 'Address was not found by geocoding service' }); });
module.exports = router;
