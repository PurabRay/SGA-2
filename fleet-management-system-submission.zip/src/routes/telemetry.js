const express = require('express');
const { randomUUID } = require('crypto');
const { state } = require('../data/store');
const { authenticate, allow } = require('../middleware/auth');
const router = express.Router();
router.post('/', authenticate, allow('admin', 'operator'), (req, res) => {
  const { vehicleId, latitude, longitude, speedKph = 0, recordedAt = new Date().toISOString() } = req.body;
  if (!vehicleId || !Number.isFinite(latitude) || !Number.isFinite(longitude)) return res.status(400).json({ error: 'vehicleId, latitude and longitude are required' });
  const vehicle = state.vehicles.find(v => v.id === vehicleId); if (!vehicle) return res.status(404).json({ error: 'Vehicle not found' });
  vehicle.latitude = latitude; vehicle.longitude = longitude;
  const record = { id: randomUUID(), vehicleId, latitude, longitude, speedKph, recordedAt }; state.telemetry.push(record);
  return res.status(201).json(record);
});
router.get('/:vehicleId', authenticate, (req, res) => res.json(state.telemetry.filter(t => t.vehicleId === req.params.vehicleId)));
module.exports = router;
